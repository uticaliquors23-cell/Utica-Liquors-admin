# Utica Liquors Website

Files included:
- `public/index.html` — the complete store website.
- `src/index.ts` — Cloudflare Worker API for shared price/stock/description edits.
- `wrangler.jsonc` — Cloudflare Worker + KV configuration.

Cloudflare KV namespace already configured:
`1992a7b1f5c745dfad397ffaae06c463`

Before deploying, create the Worker secret named `ADMIN_PASSWORD` and set it to the password you want to use for the site's **Edit Prices** panel.
